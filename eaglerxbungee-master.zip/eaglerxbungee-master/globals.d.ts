import { ProxyGlobals } from "./types.js"

declare global {
    var PROXY: ProxyGlobals
}

export {}